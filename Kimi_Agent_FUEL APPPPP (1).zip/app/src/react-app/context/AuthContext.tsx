import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';

interface User {
  id: string;
  email: string;
  name: string;
  google_user_data?: {
    picture?: string;
    name?: string;
    email?: string;
  };
}

interface AuthContextType {
  user: User | null;
  isPending: boolean;
  redirectToLogin: () => Promise<void>;
  logout: () => Promise<void>;
  exchangeCodeForSessionToken: () => Promise<void>;
  fetchUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const STORAGE_KEY = 'fuelpro_auth_user';

function loadUserFromStorage(): User | null {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch {
    // ignore
  }
  return null;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(loadUserFromStorage);
  const [isPending, setIsPending] = useState(false);

  const redirectToLogin = useCallback(async () => {
    setIsPending(true);
    // Simulate a demo login
    const demoUser: User = {
      id: 'demo_user_001',
      email: 'demo@fuelpro.app',
      name: 'Demo User',
      google_user_data: {
        picture: '',
        name: 'Demo User',
        email: 'demo@fuelpro.app',
      },
    };
    setUser(demoUser);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(demoUser));
    setIsPending(false);
    // Refresh to show logged in state
    window.location.reload();
  }, []);

  const logout = useCallback(async () => {
    setUser(null);
    localStorage.removeItem(STORAGE_KEY);
    window.location.reload();
  }, []);

  const exchangeCodeForSessionToken = useCallback(async () => {
    // No-op for demo
  }, []);

  const fetchUser = useCallback(async () => {
    // User already loaded from storage
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isPending,
        redirectToLogin,
        logout,
        exchangeCodeForSessionToken,
        fetchUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
