import { useState, useEffect } from 'react';
import Header from '@/react-app/components/Header';
import TabNavigation from '@/react-app/components/TabNavigation';
import MobileBottomNav from '@/react-app/components/MobileBottomNav';
import Dashboard from '@/react-app/components/Dashboard';
import DeliveryTracker from '@/react-app/components/DeliveryTracker';
import FuelOffloading from '@/react-app/components/FuelOffloading';
import Invoice from '@/react-app/components/Invoice';
import DebtReminder from '@/react-app/components/DebtReminder';
import SalesTracking from '@/react-app/components/SalesTracking';
import ReportsCenter from '@/react-app/components/ReportsCenter';
import MPESAAnalyzer from '@/react-app/components/MPESAAnalyzer';
import PayrollSystem from '@/react-app/components/PayrollSystem';
import DataManager from '@/react-app/components/DataManager';
import LiveTransaction from '@/react-app/components/LiveTransaction';
import FuelSalesReport from '@/react-app/components/FuelSalesReport';
import Communication from '@/react-app/components/Communication';
import Documents from '@/react-app/components/Documents';
import PointOfSale from '@/react-app/components/PointOfSale';
import AIChatbot from '@/react-app/components/AIChatbot';
import CloudSyncIndicator from '@/react-app/components/CloudSyncIndicator';
import SetupWizard from '@/react-app/components/SetupWizard';
import { useFuel } from '@/react-app/context/FuelContext';

export default function Home() {
  const { state } = useFuel();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showSetupWizard, setShowSetupWizard] = useState(false);
  
  // Check if this is first-time setup
  useEffect(() => {
    const setupComplete = localStorage.getItem('fuelpro_setup_complete');
    const hasCompanyName = state.companyData?.name && state.companyData.name !== 'My Fuel Station';
    
    // Show wizard if setup not complete AND no company name configured
    if (!setupComplete && !hasCompanyName) {
      setShowSetupWizard(true);
    }
  }, [state.companyData?.name]);

  // Listen for tab change events from Dashboard quick actions
  useEffect(() => {
    const handleChangeTab = (event: CustomEvent) => {
      setActiveTab(event.detail);
    };
    
    window.addEventListener('changeTab', handleChangeTab as EventListener);
    return () => window.removeEventListener('changeTab', handleChangeTab as EventListener);
  }, []);

  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'delivery':
        return <DeliveryTracker />;
      case 'offloading':
        return <FuelOffloading />;
      case 'invoice':
        return <Invoice />;
      case 'debt':
        return <DebtReminder />;
      case 'sales':
        return <SalesTracking />;
      case 'reports':
        return <ReportsCenter />;
      case 'mpesa':
        return <MPESAAnalyzer />;
      case 'payroll':
        return <PayrollSystem />;
      case 'data':
        return <DataManager />;
      case 'livetransaction':
        return <LiveTransaction />;
      case 'fuelsalesreport':
        return <FuelSalesReport />;
      case 'communication':
        return <Communication />;
      case 'documents':
        return <Documents />;
      case 'pos':
        return <PointOfSale />;
      default:
        return <Dashboard />;
    }
  };

  // Show setup wizard for first-time users
  if (showSetupWizard) {
    return <SetupWizard onComplete={() => setShowSetupWizard(false)} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-20 md:pb-0">
      <Header />
      
      <div className="container mx-auto px-2 md:px-4 py-2 md:py-6">
        {/* Desktop Tab Navigation - hidden on mobile */}
        <div className="hidden md:block">
          <TabNavigation activeTab={activeTab} onTabChange={setActiveTab} />
        </div>
        
        {/* Mobile: Simple header showing current tab */}
        <div className="md:hidden mb-2">
          <div className="bg-white dark:bg-gray-800 rounded-xl px-4 py-3 shadow-sm border border-gray-200 dark:border-gray-700">
            <h2 className="text-lg font-bold text-gray-800 dark:text-gray-100 capitalize">
              {activeTab === 'pos' ? 'Point of Sale' : 
               activeTab === 'mpesa' ? 'M-PESA Analysis' :
               activeTab === 'fuelsalesreport' ? 'Fuel Sales Report' :
               activeTab === 'livetransaction' ? 'Live Transactions' :
               activeTab}
            </h2>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 md:rounded-b-2xl rounded-2xl shadow-lg min-h-[calc(100vh-200px)] md:min-h-[600px]">
          {renderTabContent()}
        </div>
      </div>
      
      {/* Mobile Bottom Navigation */}
      <MobileBottomNav activeTab={activeTab} onTabChange={setActiveTab} />
      
      {/* AI Chatbot */}
      <AIChatbot />
      
      {/* Cloud Sync Status Indicator */}
      <CloudSyncIndicator />
    </div>
  );
}
