import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider, useAuth } from '@/react-app/context/AuthContext';
import HomePage from "@/react-app/pages/Home";
import AuthLogin from "@/react-app/components/AuthLogin";
import AuthCallback from "@/react-app/components/AuthCallback";
import SubscriptionChecker from "@/react-app/components/SubscriptionChecker";
import { FuelProvider } from "@/react-app/context/FuelContext";

function AppContent() {
  const { user, isPending } = useAuth();

  // Show loading screen while checking authentication
  if (isPending) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="bg-gray-800 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-gray-600 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-400 mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold text-white">Loading...</h2>
          <p className="text-gray-300 mt-2">Checking your authentication status</p>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <Routes>
        <Route 
          path="/" 
          element={user ? (
            <SubscriptionChecker>
              <FuelProvider>
                <HomePage />
              </FuelProvider>
            </SubscriptionChecker>
          ) : (
            <AuthLogin />
          )} 
        />
        <Route path="/auth/callback" element={<AuthCallback />} />
      </Routes>
    </Router>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
