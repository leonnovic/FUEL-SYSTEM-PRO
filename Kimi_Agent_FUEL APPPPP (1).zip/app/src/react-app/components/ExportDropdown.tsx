import { Download } from 'lucide-react';

interface ExportDropdownProps {
  onExport: {
    pdf: () => void;
    excel: () => void;
    txt: () => void;
    whatsapp: () => void;
    email: () => void;
  };
  title: string;
}

export default function ExportDropdown({ onExport, title }: ExportDropdownProps) {
  return (
    <div className="relative group">
      <button className="btn btn-primary">
        <Download size={16} />
        {title}
      </button>
      <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 hidden group-hover:block z-10">
        <button 
          onClick={onExport.pdf} 
          className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 rounded-t-lg"
        >
          📄 PDF
        </button>
        <button 
          onClick={onExport.excel} 
          className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          📊 Excel
        </button>
        <button 
          onClick={onExport.txt} 
          className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          📝 Text
        </button>
        <button 
          onClick={onExport.whatsapp} 
          className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          💬 WhatsApp
        </button>
        <button 
          onClick={onExport.email} 
          className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 rounded-b-lg"
        >
          📧 Email
        </button>
      </div>
    </div>
  );
}
