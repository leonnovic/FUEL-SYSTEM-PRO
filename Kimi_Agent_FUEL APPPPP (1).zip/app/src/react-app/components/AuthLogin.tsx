import { useState } from 'react';
import { useAuth } from '@/react-app/context/AuthContext';
import { LogIn, Loader2, ShieldCheck, Cloud, Zap } from 'lucide-react';

export default function AuthLogin() {
  const { redirectToLogin } = useAuth();
  const [isLoading, setIsLoading] = useState(false);

  const handleGoogleLogin = async () => {
    try {
      setIsLoading(true);
      await redirectToLogin();
    } catch (error) {
      console.error('Login failed:', error);
      alert('Login failed. Please try again.');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full grid md:grid-cols-2 gap-8">
        {/* Left Side - Branding & Features */}
        <div className="hidden md:flex flex-col justify-center space-y-6 text-white">
          <div className="space-y-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-14 h-14 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
                <span className="text-3xl">⛽</span>
              </div>
              <div>
                <h1 className="text-4xl font-bold">FuelPro</h1>
                <p className="text-blue-300 text-sm">Professional Fuel Management</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="text-2xl font-semibold">Welcome to your comprehensive fuel management solution</h2>
            
            <div className="space-y-3">
              <div className="flex items-start gap-3 bg-white/5 backdrop-blur-sm rounded-lg p-4 border border-white/10">
                <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Cloud className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Cloud Sync</h3>
                  <p className="text-sm text-gray-300">Your data securely synced across all devices in real-time</p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white/5 backdrop-blur-sm rounded-lg p-4 border border-white/10">
                <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <ShieldCheck className="w-5 h-5 text-green-400" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Secure Authentication</h3>
                  <p className="text-sm text-gray-300">Enterprise-grade security powered by Google OAuth</p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white/5 backdrop-blur-sm rounded-lg p-4 border border-white/10">
                <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Zap className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Real-Time Updates</h3>
                  <p className="text-sm text-gray-300">Track sales, deliveries, and payments as they happen</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-4">
            <div className="bg-white/5 backdrop-blur-sm rounded-lg p-3 border border-white/10 text-center">
              <div className="text-2xl mb-1">📊</div>
              <div className="text-xs font-semibold">Sales Tracking</div>
            </div>
            <div className="bg-white/5 backdrop-blur-sm rounded-lg p-3 border border-white/10 text-center">
              <div className="text-2xl mb-1">🚛</div>
              <div className="text-xs font-semibold">Delivery Management</div>
            </div>
            <div className="bg-white/5 backdrop-blur-sm rounded-lg p-3 border border-white/10 text-center">
              <div className="text-2xl mb-1">📄</div>
              <div className="text-xs font-semibold">Invoice System</div>
            </div>
            <div className="bg-white/5 backdrop-blur-sm rounded-lg p-3 border border-white/10 text-center">
              <div className="text-2xl mb-1">💰</div>
              <div className="text-xs font-semibold">M-PESA Analytics</div>
            </div>
          </div>
        </div>

        {/* Right Side - Login Form */}
        <div className="flex flex-col justify-center">
          {/* Mobile Logo */}
          <div className="md:hidden text-center mb-8">
            <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
              <span className="text-3xl">⛽</span>
            </div>
            <h1 className="text-3xl font-bold text-white mb-1">FuelPro</h1>
            <p className="text-blue-300 text-sm">Professional Fuel Management System</p>
          </div>

          <div className="bg-gray-800/90 backdrop-blur-xl rounded-2xl p-8 shadow-2xl border border-gray-700">
            <h2 className="text-2xl font-bold text-white mb-6 text-center">
              Sign In to Continue
            </h2>
            
            <div className="space-y-4">
              <button
                onClick={handleGoogleLogin}
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-3 bg-white hover:bg-gray-100 text-gray-900 font-semibold py-3.5 px-6 rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed group"
              >
                {isLoading ? (
                  <Loader2 size={20} className="animate-spin" />
                ) : (
                  <>
                    <img 
                      src="https://www.google.com/favicon.ico" 
                      alt="Google" 
                      className="w-5 h-5"
                    />
                    <span>Continue with Google</span>
                    <LogIn size={20} className="group-hover:translate-x-0.5 transition-transform" />
                  </>
                )}
              </button>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-600"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-4 bg-gray-800 text-gray-400">Secure authentication</span>
                </div>
              </div>

              <div className="bg-blue-900/20 border border-blue-700/50 rounded-lg p-4">
                <p className="text-blue-300 text-sm text-center">
                  <strong>Note:</strong> We use Google OAuth for secure, enterprise-grade authentication.
                  Additional login methods coming soon.
                </p>
              </div>

              {/* Features list */}
              <div className="mt-6 pt-6 border-t border-gray-700">
                <h3 className="font-semibold text-white mb-3 text-center">What you get:</h3>
                <ul className="space-y-2.5 text-sm text-gray-300">
                  <li className="flex items-center gap-2">
                    <span className="text-green-400 text-lg">✓</span>
                    <span>Secure data encryption and privacy protection</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-green-400 text-lg">✓</span>
                    <span>Access from any device, anywhere, anytime</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-green-400 text-lg">✓</span>
                    <span>Real-time sync every 15 seconds</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-green-400 text-lg">✓</span>
                    <span>Complete control over your business data</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center mt-6">
            <p className="text-gray-400 text-sm">
              Secure • Reliable • Professional
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
