import { useState, useEffect, ReactNode } from 'react';
import { useAuth } from '@/react-app/context/AuthContext';

interface SubscriptionCheckerProps {
  children: ReactNode;
}

export default function SubscriptionChecker({ children }: SubscriptionCheckerProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate brief loading then allow access
    const timer = setTimeout(() => {
      setLoading(false);
    }, 500);
    return () => clearTimeout(timer);
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="bg-gray-800 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-gray-600 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-400 mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold text-white">Loading FuelPro...</h2>
          <p className="text-gray-300 mt-2">Preparing your dashboard</p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
