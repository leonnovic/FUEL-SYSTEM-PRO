import { useState, useEffect, useRef } from 'react';
import { Upload, Download, Calculator, Clock, AlertCircle, CheckCircle2, Sparkles, Zap, RefreshCw } from 'lucide-react';
import { useFuel } from '@/react-app/context/FuelContext';

// PDF.js types
declare global {
  interface Window {
    pdfjsLib: any;
  }
}

interface InflowData {
  receipt: string;
  time: string;
  paidIn: number;
  fee?: number;
  balanceAfter?: number;
  transactionType?: string;
  counterparty?: string;
  counterpartyPhone?: string;
  counterpartyType?: string;
  details: string;
  source?: 'AI' | 'Pattern' | 'Aggressive';
}

interface ExcludedData {
  receipt: string;
  time: string;
  details: string;
  paidIn: number;
  withdrawn: number;
  reason: string;
  transactionType?: string;
}

interface WithdrawalData {
  receipt: string;
  time: string;
  details: string;
  withdrawn: number;
  fee?: number;
  transactionType?: string;
  counterparty?: string;
  counterpartyType?: string;
}

interface MerchantInfo {
  name: string;
  shortcode: string;
  period: string;
  requestDate?: string;
}

interface AnalysisStats {
  totalInflows: number;
  totalAmount: number;
  totalExcluded: number;
  totalWithdrawals: number;
  totalFees: number;
  totalCustomerPayments?: number;
  uniqueCustomers?: number;
  netPosition?: number;
  dateRange: { earliest: string; latest: string } | null;
  averageTransaction: number;
  extractionMethod?: string;
  pagesProcessed?: number;
  textItemsFound?: number;
}

export default function MPESAAnalyzer() {
  const { } = useFuel();
  const [activeTab, setActiveTab] = useState('receipt');
  const [fileName, setFileName] = useState('No file selected');
  const [progress, setProgress] = useState('Ready to process M-PESA statement.');
  const [output, setOutput] = useState('Upload PDF to see extracted data...');
  const [result, setResult] = useState('');
  const [inflowData, setInflowData] = useState<InflowData[]>([]);
  const [excludedData, setExcludedData] = useState<ExcludedData[]>([]);
  const [, setWithdrawalData] = useState<WithdrawalData[]>([]);
  const [stats, setStats] = useState<AnalysisStats | null>(null);
  const [merchantInfo, setMerchantInfo] = useState<MerchantInfo | null>(null);
  const [useAI, setUseAI] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showExcluded, setShowExcluded] = useState(false);
  
  const [startReceipt, setStartReceipt] = useState('');
  const [endReceipt, setEndReceipt] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const dropZoneRef = useRef<HTMLDivElement>(null);
  const [pdfLoaded, setPdfLoaded] = useState(false);

  useEffect(() => {
    // Load PDF.js
    if (window.pdfjsLib) {
      setPdfLoaded(true);
      return;
    }
    
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js';
    script.onload = () => {
      if (window.pdfjsLib) {
        window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';
        setPdfLoaded(true);
      }
    };
    document.head.appendChild(script);

    return () => {
      try {
        if (script.parentNode) {
          document.head.removeChild(script);
        }
      } catch (e) {
        // Ignore cleanup errors
      }
    };
  }, []);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (dropZoneRef.current) {
      dropZoneRef.current.classList.add('border-blue-600', 'bg-blue-100', 'dark:bg-blue-900/40');
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    if (dropZoneRef.current) {
      dropZoneRef.current.classList.remove('border-blue-600', 'bg-blue-100', 'dark:bg-blue-900/40');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (dropZoneRef.current) {
      dropZoneRef.current.classList.remove('border-blue-600', 'bg-blue-100', 'dark:bg-blue-900/40');
    }

    const files = e.dataTransfer.files;
    if (files.length === 0) return;

    const file = files[0];
    if (file.type && file.type !== 'application/pdf') {
      alert('Please upload a PDF file.');
      return;
    }

    if (fileInputRef.current) {
      const dt = new DataTransfer();
      dt.items.add(file);
      fileInputRef.current.files = dt.files;
    }
    setFileName(file.name);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFileName(e.target.files[0].name);
    } else {
      setFileName('No file selected');
    }
  };

  // ===== EXTRACTION METHOD 1: Structured Table Extraction =====
  const extractPageTextStructured = (textContent: any): string => {
    if (!textContent.items || textContent.items.length === 0) return '';
    
    const rows: { [key: number]: { x: number; str: string; width: number }[] } = {};
    const yTolerance = 6; // Tolerance for row grouping
    
    textContent.items.forEach((item: any) => {
      if (!item.str || !item.str.trim()) return;
      
      const y = Math.round(item.transform?.[5] || 0);
      const x = Math.round(item.transform?.[4] || 0);
      const width = Math.round(item.width || 0);
      
      // Find existing row or create new one
      let rowKey = y;
      for (const existingY of Object.keys(rows).map(Number)) {
        if (Math.abs(existingY - y) <= yTolerance) {
          rowKey = existingY;
          break;
        }
      }
      
      if (!rows[rowKey]) rows[rowKey] = [];
      rows[rowKey].push({ x, str: item.str, width });
    });
    
    // Sort rows top to bottom
    const sortedYs = Object.keys(rows).map(Number).sort((a, b) => b - a);
    
    let pageText = '';
    sortedYs.forEach(y => {
      const rowItems = rows[y].sort((a, b) => a.x - b.x);
      let prevX = 0;
      let rowText = '';
      
      rowItems.forEach(item => {
        const gap = item.x - prevX;
        // Add column separators for large gaps
        if (gap > 80 && rowText.length > 0) {
          rowText += ' | ';
        } else if (gap > 15 && rowText.length > 0) {
          rowText += ' ';
        }
        rowText += item.str;
        prevX = item.x + item.width;
      });
      
      pageText += rowText.trim() + '\n';
    });
    
    return pageText;
  };

  // ===== EXTRACTION METHOD 2: Raw Sequential Extraction =====
  const extractPageTextRaw = (textContent: any): string => {
    if (!textContent.items || textContent.items.length === 0) return '';
    return textContent.items
      .map((item: any) => item.str || '')
      .filter((s: string) => s.trim())
      .join(' ');
  };

  // ===== EXTRACTION METHOD 3: Line-by-line with Aggressive Grouping =====
  const extractPageTextAggressive = (textContent: any): string => {
    if (!textContent.items || textContent.items.length === 0) return '';
    
    // Sort all items by Y (top to bottom) then X (left to right)
    const sortedItems = [...textContent.items]
      .filter((item: any) => item.str && item.str.trim())
      .sort((a: any, b: any) => {
        const yDiff = (b.transform?.[5] || 0) - (a.transform?.[5] || 0);
        if (Math.abs(yDiff) < 10) {
          return (a.transform?.[4] || 0) - (b.transform?.[4] || 0);
        }
        return yDiff;
      });
    
    let result = '';
    let lastY: number | null = null;
    
    sortedItems.forEach((item: any) => {
      const y = Math.round(item.transform?.[5] || 0);
      if (lastY !== null && Math.abs(y - lastY) > 10) {
        result += '\n';
      } else if (result.length > 0 && !result.endsWith(' ') && !result.endsWith('\n')) {
        result += ' ';
      }
      result += item.str;
      lastY = y;
    });
    
    return result;
  };

  // ===== EXTRACTION METHOD 4: Pattern-focused extraction =====
  const extractPageTextPatternFocused = (textContent: any): string => {
    if (!textContent.items || textContent.items.length === 0) return '';
    
    const items = textContent.items.filter((item: any) => item.str && item.str.trim());
    let result = '';
    
    // Group items by vertical position with generous tolerance
    const groups: { y: number; items: any[] }[] = [];
    
    items.forEach((item: any) => {
      const y = Math.round(item.transform?.[5] || 0);
      const existingGroup = groups.find(g => Math.abs(g.y - y) < 12);
      
      if (existingGroup) {
        existingGroup.items.push(item);
      } else {
        groups.push({ y, items: [item] });
      }
    });
    
    // Sort groups by Y descending and items within by X
    groups.sort((a, b) => b.y - a.y);
    
    groups.forEach(group => {
      group.items.sort((a: any, b: any) => (a.transform?.[4] || 0) - (b.transform?.[4] || 0));
      const lineText = group.items.map((item: any) => item.str).join(' ');
      result += lineText + '\n';
    });
    
    return result;
  };

  const processPDF = async () => {
    if (!fileInputRef.current?.files?.[0]) {
      alert('Please upload a PDF file.');
      return;
    }

    if (!pdfLoaded || !window.pdfjsLib) {
      alert('PDF library is still loading. Please wait a moment and try again.');
      return;
    }

    const file = fileInputRef.current.files[0];
    setOutput('');
    setProgress('📄 Reading PDF file...');
    setResult('');
    setInflowData([]);
    setExcludedData([]);
    setWithdrawalData([]);
    setStats(null);
    setMerchantInfo(null);
    setIsProcessing(true);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const data = new Uint8Array(arrayBuffer);
      
      setProgress('📄 Opening PDF document...');
      
      // Try multiple PDF loading strategies
      let pdf;
      const loadingStrategies = [
        { verbosity: 0, enableXfa: true, stopAtErrors: false, disableFontFace: false },
        { verbosity: 0, enableXfa: false, stopAtErrors: false, disableFontFace: true },
        { verbosity: 0, enableXfa: true, stopAtErrors: true, disableFontFace: false },
        { verbosity: 0 } // Minimal options fallback
      ];
      
      for (const options of loadingStrategies) {
        try {
          const loadingTask = window.pdfjsLib.getDocument({ data, ...options });
          pdf = await loadingTask.promise;
          break;
        } catch (loadError) {
          console.warn('PDF loading strategy failed:', loadError);
          continue;
        }
      }
      
      if (!pdf) {
        throw new Error('Could not open PDF. The file may be corrupted or password protected.');
      }

      setProgress(`📄 PDF opened: ${pdf.numPages} page(s) detected`);

      // Arrays to hold all extraction results
      let structuredText = '';
      let rawText = '';
      let aggressiveText = '';
      let patternText = '';
      let totalItems = 0;
      let validPages = 0;

      // Process each page with all extraction methods
      for (let i = 1; i <= pdf.numPages; i++) {
        setProgress(`🔍 Extracting page ${i} of ${pdf.numPages}...\n📊 Using 4 extraction methods for maximum coverage\n📝 ${totalItems} text items found so far`);
        
        try {
          const page = await pdf.getPage(i);
          const textContent = await page.getTextContent();
          
          if (textContent.items && textContent.items.length > 0) {
            validPages++;
            totalItems += textContent.items.length;
            
            // Run all extraction methods
            const structured = extractPageTextStructured(textContent);
            const raw = extractPageTextRaw(textContent);
            const aggressive = extractPageTextAggressive(textContent);
            const pattern = extractPageTextPatternFocused(textContent);
            
            structuredText += `\n=== PAGE ${i} (STRUCTURED) ===\n` + structured;
            rawText += `\n=== PAGE ${i} (RAW) ===\n` + raw;
            aggressiveText += `\n=== PAGE ${i} (AGGRESSIVE) ===\n` + aggressive;
            patternText += `\n=== PAGE ${i} (PATTERN) ===\n` + pattern;
          }
        } catch (pageError) {
          console.warn(`Error processing page ${i}:`, pageError);
          // Continue to next page
        }
      }

      if (totalItems === 0) {
        throw new Error('PDF appears to be empty or contains only images. Try a text-based PDF.');
      }

      // Combine all extraction methods for comprehensive analysis
      let combinedText = `
========================================
M-PESA STATEMENT EXTRACTION
File: ${file.name}
Pages: ${pdf.numPages}
Text Items: ${totalItems}
Extraction Methods: 4 (Structured, Raw, Aggressive, Pattern-focused)
========================================

${structuredText}

========== ALTERNATIVE EXTRACTION: RAW ==========
${rawText}

========== ALTERNATIVE EXTRACTION: AGGRESSIVE ==========
${aggressiveText}

========== ALTERNATIVE EXTRACTION: PATTERN-FOCUSED ==========
${patternText}
`;

      // Clean up text while preserving structure
      combinedText = combinedText
        .replace(/[ \t]+/g, ' ')
        .replace(/\n\s*\n\s*\n+/g, '\n\n')
        .trim();

      setProgress(`✅ Text extracted: ${validPages} pages, ${totalItems} items\n🔄 Preparing for analysis...`);

      // Process with AI or manual parsing
      if (useAI) {
        await processWithAI(combinedText, validPages, totalItems);
      } else {
        processManually(combinedText, validPages, totalItems);
      }

    } catch (error) {
      const errorMessage = (error as Error).message;
      setProgress(`❌ Error: ${errorMessage}`);
      console.error('PDF Processing Error:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const processWithAI = async (fullText: string, pagesProcessed: number, textItemsFound: number) => {
    // ===== HYBRID APPROACH: Run pattern extraction and AI in parallel =====
    setProgress(`🔄 Starting hybrid extraction...\n📊 ${pagesProcessed} pages, ${textItemsFound} text items\n🔍 Running pattern extraction + AI simultaneously`);
    
    // Step 1: Run pattern-based extraction immediately (fast, reliable baseline)
    const patternResult = parseMpesaTransactions(fullText);
    
    setProgress(`✅ Pattern extraction: ${patternResult.inflows.length} inflows, ${patternResult.withdrawals.length} withdrawals\n🤖 Enhancing with AI analysis...`);
    
    // Step 2: Run AI analysis for enhanced details and any missed transactions
    let aiResult: any = null;
    let aiError: string | null = null;
    const maxRetries = 100;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        const response = await fetch('/api/mpesa/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pdfText: fullText, fileName })
        });
        
        if (response.ok) {
          aiResult = await response.json();
          if (aiResult.error) {
            // Check if it's a recoverable error
            if ((aiResult.errorCode === 'RATE_LIMITED' || aiResult.errorCode === 'TIMEOUT' || aiResult.errorCode === 'NETWORK') && attempt < maxRetries) {
              setProgress(`⏳ AI busy, retrying... (attempt ${attempt}/${maxRetries})`);
              await new Promise(resolve => setTimeout(resolve, 500));
              continue;
            }
            aiError = aiResult.error;
            aiResult = null;
          } else {
            // Success - break out of retry loop
            break;
          }
        } else {
          if (attempt < maxRetries) {
            setProgress(`⏳ Retrying AI analysis... (attempt ${attempt}/${maxRetries})`);
            await new Promise(resolve => setTimeout(resolve, 500));
            continue;
          }
          aiError = `Server error: ${response.status}`;
        }
      } catch (error) {
        if (attempt < maxRetries) {
          setProgress(`⏳ Connection issue, retrying... (attempt ${attempt}/${maxRetries})`);
          await new Promise(resolve => setTimeout(resolve, 500));
          continue;
        }
        aiError = (error as Error).message;
      }
    }
    
    // Step 3: Merge results - AI provides enhanced details, pattern fills gaps
    const mergedInflows: InflowData[] = [];
    const mergedExcluded: ExcludedData[] = [];
    const mergedWithdrawals: WithdrawalData[] = [];
    const processedReceipts = new Set<string>();
    
    // Process AI results first (they have richer details)
    if (aiResult && !aiResult.error) {
      const aiInflows = (aiResult.inflows || []).map((item: any) => ({
        receipt: String(item.receipt || '').toUpperCase(),
        time: item.time || '',
        paidIn: Number(item.paidIn) || 0,
        fee: Number(item.fee) || 0,
        balanceAfter: Number(item.balanceAfter) || undefined,
        transactionType: item.transactionType || '',
        counterparty: item.counterparty || '',
        counterpartyPhone: item.counterpartyPhone || '',
        counterpartyType: item.counterpartyType || '',
        details: item.details || '',
        source: 'AI'
      })).filter((item: InflowData) => item.receipt && item.paidIn > 0);
      
      aiInflows.forEach((item: InflowData) => {
        if (!processedReceipts.has(item.receipt)) {
          processedReceipts.add(item.receipt);
          mergedInflows.push(item);
        }
      });
      
      const aiExcluded = (aiResult.excluded || []).map((item: any) => ({
        receipt: String(item.receipt || '').toUpperCase(),
        time: item.time || '',
        paidIn: Number(item.paidIn) || 0,
        withdrawn: Number(item.withdrawn) || 0,
        details: item.details || '',
        reason: item.reason || 'Flagged for manual review',
        transactionType: item.transactionType || ''
      }));
      
      aiExcluded.forEach((item: ExcludedData) => {
        if (!processedReceipts.has(item.receipt)) {
          processedReceipts.add(item.receipt);
          mergedExcluded.push(item);
        }
      });
      
      const aiWithdrawals = (aiResult.withdrawals || []).map((item: any) => ({
        receipt: String(item.receipt || '').toUpperCase(),
        time: item.time || '',
        withdrawn: Number(item.withdrawn) || 0,
        fee: Number(item.fee) || 0,
        details: item.details || '',
        transactionType: item.transactionType || '',
        counterparty: item.counterparty || '',
        counterpartyType: item.counterpartyType || ''
      }));
      
      aiWithdrawals.forEach((item: WithdrawalData) => {
        if (!processedReceipts.has(item.receipt)) {
          processedReceipts.add(item.receipt);
          mergedWithdrawals.push(item);
        }
      });
    }
    
    // Step 4: Add pattern-extracted transactions not found by AI
    let patternAdditions = 0;
    
    patternResult.inflows.forEach(item => {
      if (!processedReceipts.has(item.receipt)) {
        processedReceipts.add(item.receipt);
        mergedInflows.push({ ...item, source: 'Pattern' } as InflowData);
        patternAdditions++;
      }
    });
    
    patternResult.excluded.forEach(item => {
      if (!processedReceipts.has(item.receipt)) {
        processedReceipts.add(item.receipt);
        mergedExcluded.push(item);
        patternAdditions++;
      }
    });
    
    patternResult.withdrawals.forEach(item => {
      if (!processedReceipts.has(item.receipt)) {
        processedReceipts.add(item.receipt);
        mergedWithdrawals.push(item);
        patternAdditions++;
      }
    });
    
    // Step 5: If we still have very few results, run aggressive receipt finder
    if (mergedInflows.length < 3 && textItemsFound > 100) {
      setProgress(`⚠️ Few transactions found. Running aggressive extraction...`);
      const aggressiveResult = parseAggressively(fullText);
      
      aggressiveResult.inflows.forEach(item => {
        if (!processedReceipts.has(item.receipt)) {
          processedReceipts.add(item.receipt);
          mergedInflows.push({ ...item, source: 'Aggressive' } as InflowData);
        }
      });
    }
    
    // Store merchant info from AI if available
    if (aiResult?.merchantInfo) {
      setMerchantInfo(aiResult.merchantInfo);
    }
    
    // Sort by time
    mergedInflows.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());
    
    // Calculate statistics
    const aiSummary = aiResult?.summary || {};
    const totalAmount = mergedInflows.reduce((sum, item) => sum + item.paidIn, 0);
    const avgTransaction = mergedInflows.length > 0 ? totalAmount / mergedInflows.length : 0;
    const totalFees = mergedInflows.reduce((sum, item) => sum + (item.fee || 0), 0);
    
    // Determine extraction method description
    const aiCount = mergedInflows.filter((i: any) => i.source === 'AI').length;
    const patternCount = mergedInflows.filter((i: any) => i.source === 'Pattern').length;
    const aggressiveCount = mergedInflows.filter((i: any) => i.source === 'Aggressive').length;
    let methodDesc = 'Hybrid';
    if (aiCount > 0 && patternCount > 0) {
      methodDesc = `Hybrid (AI: ${aiCount}, Pattern: ${patternCount}${aggressiveCount ? `, Aggressive: ${aggressiveCount}` : ''})`;
    } else if (aiCount > 0) {
      methodDesc = 'AI (Gemini)';
    } else if (patternCount > 0) {
      methodDesc = 'Pattern-based';
    }
    
    const analysisStats: AnalysisStats = {
      totalInflows: mergedInflows.length,
      totalAmount,
      totalExcluded: mergedExcluded.length,
      totalWithdrawals: mergedWithdrawals.length,
      totalFees,
      totalCustomerPayments: aiSummary.totalCustomerPayments || 0,
      uniqueCustomers: aiSummary.uniqueCustomers || new Set(mergedInflows.map(i => i.counterpartyPhone).filter(Boolean)).size,
      netPosition: aiSummary.netPosition || 0,
      dateRange: mergedInflows.length > 0 ? {
        earliest: mergedInflows[0].time,
        latest: mergedInflows[mergedInflows.length - 1].time
      } : null,
      averageTransaction: avgTransaction,
      extractionMethod: methodDesc,
      pagesProcessed,
      textItemsFound
    };

    setInflowData(mergedInflows);
    setExcludedData(mergedExcluded);
    setWithdrawalData(mergedWithdrawals);
    setStats(analysisStats);
    displayInflows(mergedInflows);
    
    // Build completion message
    let statusNote = '';
    if (aiError) {
      // Make the message friendly - focus on success, not failure
      if (mergedInflows.length > 0) {
        statusNote = `\n✅ Pattern extraction completed successfully (${mergedInflows.length} transactions found)`;
      } else {
        statusNote = `\n📋 Using pattern extraction mode`;
      }
    } else if (patternAdditions > 0) {
      statusNote = `\n✨ Pattern extraction found ${patternAdditions} additional transactions missed by AI`;
    }
    
    buildCompletionMessage(analysisStats, aiResult?.merchantInfo || null, mergedExcluded, mergedWithdrawals, methodDesc);
    if (statusNote) {
      setProgress(prev => prev + statusNote);
    }
  };
  
  // Aggressive extraction - last resort for difficult PDFs
  const parseAggressively = (text: string) => {
    const inflows: InflowData[] = [];
    const seenReceipts = new Set<string>();
    
    // Find ANY receipt-like pattern
    const allReceipts = text.match(/T[A-Z][A-Z0-9]{7,12}/gi) || [];
    
    allReceipts.forEach((receipt: string) => {
      const normalized = receipt.toUpperCase();
      if (seenReceipts.has(normalized)) return;
      seenReceipts.add(normalized);
      
      // Find context around this receipt
      const idx = text.indexOf(receipt);
      if (idx === -1) return;
      
      const context = text.substring(Math.max(0, idx - 50), Math.min(text.length, idx + 300));
      
      // Look for any amount patterns
      const amounts = context.match(/[\d,]+\.\d{2}/g) || [];
      const parsedAmounts = amounts.map(a => parseFloat(a.replace(/,/g, ''))).filter(n => n > 0 && n < 10000000);
      
      // Look for date/time
      const timeMatch = context.match(/(\d{1,2}\/\d{1,2}\/\d{2,4}[\s]+\d{1,2}:\d{2}(?::\d{2})?)/);
      let time = timeMatch ? timeMatch[1] : '';
      
      // Normalize date
      if (time.includes('/')) {
        const [datePart, timePart] = time.split(/\s+/);
        const parts = datePart.split('/');
        if (parts.length === 3) {
          const [day, month, year] = parts;
          const fullYear = year.length === 2 ? `20${year}` : year;
          time = `${fullYear}-${month.padStart(2, '0')}-${day.padStart(2, '0')} ${timePart || '00:00:00'}`;
        }
      }
      
      if (parsedAmounts.length > 0 && time) {
        // Assume first amount is paid in unless context suggests withdrawal
        const isWithdrawal = context.toLowerCase().includes('withdraw') || 
                            context.toLowerCase().includes('payment to') ||
                            context.toLowerCase().includes('buy goods');
        
        if (!isWithdrawal) {
          inflows.push({
            receipt: normalized,
            time,
            paidIn: parsedAmounts[0],
            details: context.substring(0, 100).replace(/\s+/g, ' ').trim()
          });
        }
      }
    });
    
    return { inflows, excluded: [], withdrawals: [] };
  };

  const processManually = (fullText: string, pagesProcessed: number, textItemsFound: number) => {
    setProgress('🔍 Running multi-method pattern extraction...');

    // Run primary pattern extraction
    const result = parseMpesaTransactions(fullText);
    
    // If few results, supplement with aggressive extraction
    if (result.inflows.length < 5 && textItemsFound > 100) {
      setProgress('⚡ Running aggressive extraction for additional transactions...');
      const aggressiveResult = parseAggressively(fullText);
      const existingReceipts = new Set(result.inflows.map(i => i.receipt));
      
      aggressiveResult.inflows.forEach(item => {
        if (!existingReceipts.has(item.receipt)) {
          result.inflows.push({ ...item, source: 'Aggressive' } as InflowData);
        }
      });
    }
    
    // Sort by time
    result.inflows.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());
    
    // Calculate statistics
    const totalAmount = result.inflows.reduce((sum, item) => sum + item.paidIn, 0);
    const avgTransaction = result.inflows.length > 0 ? totalAmount / result.inflows.length : 0;
    
    const analysisStats: AnalysisStats = {
      totalInflows: result.inflows.length,
      totalAmount,
      totalExcluded: result.excluded.length,
      totalWithdrawals: result.withdrawals.length,
      totalFees: 0,
      totalCustomerPayments: 0,
      uniqueCustomers: 0,
      netPosition: 0,
      dateRange: result.inflows.length > 0 ? {
        earliest: result.inflows[0].time,
        latest: result.inflows[result.inflows.length - 1].time
      } : null,
      averageTransaction: avgTransaction,
      extractionMethod: 'Pattern-based (Multi-method)',
      pagesProcessed,
      textItemsFound
    };

    setInflowData(result.inflows);
    setExcludedData(result.excluded);
    setWithdrawalData(result.withdrawals);
    setStats(analysisStats);
    displayInflows(result.inflows);
    
    buildCompletionMessage(analysisStats, null, result.excluded, result.withdrawals, 'Manual');
  };

  const parseMpesaTransactions = (text: string) => {
    const inflows: InflowData[] = [];
    const excluded: ExcludedData[] = [];
    const withdrawals: WithdrawalData[] = [];
    const seenReceipts = new Set<string>();

    // Multiple receipt patterns to catch various formats and OCR errors
    const receiptPatterns = [
      /\b(T[A-Z][A-Z0-9]{8,12})\b/gi,
      /\b(TI[A-Z0-9]{6,10})\b/gi,
      /\b(TIE[A-Z0-9]{5,9})\b/gi,
      /\b(TID[A-Z0-9]{5,9})\b/gi,
      /\b(TE[A-Z0-9]{7,11})\b/gi,
      /\b(TX[A-Z0-9]{7,11})\b/gi
    ];
    
    // Find all receipt numbers with their positions
    const allMatches: { receipt: string; index: number }[] = [];
    
    for (const pattern of receiptPatterns) {
      const matches = Array.from(text.matchAll(pattern));
      matches.forEach(match => {
        const receipt = match[0].toUpperCase().replace(/\s+/g, '');
        if (!seenReceipts.has(receipt) && receipt.length >= 8 && receipt.length <= 14) {
          seenReceipts.add(receipt);
          allMatches.push({ receipt, index: match.index || 0 });
        }
      });
    }
    
    // Sort by position in text
    allMatches.sort((a, b) => a.index - b.index);
    
    // Process each receipt
    for (let i = 0; i < allMatches.length; i++) {
      const { receipt: receiptNo, index: startPos } = allMatches[i];
      const endPos = i < allMatches.length - 1 ? allMatches[i + 1].index : text.length;
      const block = text.substring(startPos, Math.min(endPos, startPos + 600));

      // Extract time with multiple date formats
      let time = '';
      const timePatterns = [
        /(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})/,
        /(\d{2}\/\d{2}\/\d{4}\s+\d{2}:\d{2}:\d{2})/,
        /(\d{1,2}\/\d{1,2}\/\d{2,4}\s+\d{1,2}:\d{2}(?::\d{2})?)/i,
        /(\d{2}-\d{2}-\d{4}\s+\d{2}:\d{2}:\d{2})/
      ];
      
      for (const pattern of timePatterns) {
        const match = block.match(pattern);
        if (match) {
          time = match[1];
          // Normalize date format
          if (time.includes('/')) {
            const [datePart, timePart] = time.split(/\s+/);
            const parts = datePart.split('/');
            if (parts.length === 3) {
              const [day, month, year] = parts;
              const fullYear = year.length === 2 ? `20${year}` : year;
              time = `${fullYear}-${month.padStart(2, '0')}-${day.padStart(2, '0')} ${timePart || '00:00:00'}`;
            }
          }
          break;
        }
      }
      
      if (!time) continue;

      // Clean and parse amounts
      const cleanAmount = (str: string): number => {
        if (!str) return 0;
        // Handle OCR errors
        const cleaned = str
          .replace(/[Oo]/g, '0')
          .replace(/[lI]/g, '1')
          .replace(/[,\s]/g, '')
          .replace(/[^\d.]/g, '');
        const num = parseFloat(cleaned);
        return isNaN(num) ? 0 : Math.round(num * 100) / 100;
      };

      // Multiple patterns for "Paid in"
      let paidIn = 0;
      const paidInPatterns = [
        /Paid\s*[Ii]n[:\s]*([\d,]+\.?\d*)/i,
        /Paid[\s]*In[:\s]*([\d,]+\.?\d*)/i,
        /Completed[:\s]*([\d,]+\.?\d*)\s+0\.00/i,
        /\|\s*([\d,]+\.?\d+)\s*\|\s*0\.00\s*\|/,
        /([\d,]+\.?\d*)\s+0\.00\s+[\d,]+\.?\d*\s*$/m,
        /received[^\d]*([\d,]+\.?\d*)/i,
        /Customer[^\d]*([\d,]+\.?\d*)/i
      ];
      
      for (const pattern of paidInPatterns) {
        const match = block.match(pattern);
        if (match) {
          const amount = cleanAmount(match[1]);
          if (amount > paidIn && amount < 100000000) {
            paidIn = amount;
          }
        }
      }

      // Multiple patterns for "Withdrawn"
      let withdrawn = 0;
      const withdrawnPatterns = [
        /Withdrawn[:\s]*([\d,]+\.?\d*)/i,
        /With\s*drawn[:\s]*([\d,]+\.?\d*)/i,
        /0\.00\s+([\d,]+\.?\d*)\s+[\d,]+/,
        /\|\s*0\.00\s*\|\s*([\d,]+\.?\d+)\s*\|/
      ];
      
      for (const pattern of withdrawnPatterns) {
        const match = block.match(pattern);
        if (match) {
          const amount = cleanAmount(match[1]);
          if (amount > withdrawn && amount < 100000000) {
            withdrawn = amount;
          }
        }
      }

      // Extract transaction details
      let details = block.substring(receiptNo.length, Math.min(block.length, 200))
        .replace(/\s+/g, ' ')
        .trim();

      if (paidIn === 0 && withdrawn === 0) continue;

      // Check for loan disbursements to exclude
      const loanKeywords = [
        'loan', 'fuliza', 'm-shwari', 'mshwari', 'kcb m-pesa', 
        'disbursed', 'disbursement', 'advance', 'boost ya biashara',
        'credit facility', 'borrowed', 'working capital'
      ];
      const detailsLower = details.toLowerCase();
      const isLoanDisbursement = loanKeywords.some(kw => detailsLower.includes(kw));

      // Classify transaction
      if (paidIn > 0 && withdrawn === 0) {
        if (isLoanDisbursement) {
          excluded.push({
            receipt: receiptNo,
            time,
            details: details || 'Loan Disbursement',
            paidIn,
            withdrawn: 0,
            reason: 'Loan disbursement - excluded from inflows',
            transactionType: 'Loan'
          });
        } else {
          inflows.push({
            receipt: receiptNo,
            time,
            paidIn,
            details: details || 'Inflow Transaction'
          });
        }
      } else if (withdrawn > 0 && paidIn === 0) {
        withdrawals.push({
          receipt: receiptNo,
          time,
          details: details || 'Withdrawal',
          withdrawn
        });
      } else if (paidIn > 0 && withdrawn > 0) {
        // Both values present - unusual, exclude for review
        excluded.push({
          receipt: receiptNo,
          time,
          details: details || 'Mixed transaction',
          paidIn,
          withdrawn,
          reason: 'Has both inflow and outflow - needs review'
        });
      }
    }

    return { inflows, excluded, withdrawals };
  };

  const buildCompletionMessage = (
    analysisStats: AnalysisStats, 
    merchant: MerchantInfo | null, 
    excluded: ExcludedData[], 
    withdrawals: WithdrawalData[],
    method: string
  ) => {
    let message = `✅ Analysis Complete! (${method} Extraction)\n\n`;
    
    if (merchant?.name) {
      message += `🏪 Merchant: ${merchant.name}\n`;
      if (merchant.shortcode && merchant.shortcode !== 'N/A') {
        message += `📱 Shortcode: ${merchant.shortcode}\n`;
      }
      if (merchant.period) {
        message += `📆 Period: ${merchant.period}\n`;
      }
      message += `\n`;
    }
    
    if (analysisStats.totalInflows > 0) {
      message += `📊 Valid Inflows: ${analysisStats.totalInflows}\n`;
      message += `💰 Total Amount: KES ${analysisStats.totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n`;
      message += `📈 Average: KES ${analysisStats.averageTransaction.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n`;
      
      if (analysisStats.totalFees > 0) {
        message += `💳 Total Fees: KES ${analysisStats.totalFees.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n`;
      }
      
      if (analysisStats.uniqueCustomers && analysisStats.uniqueCustomers > 0) {
        message += `👥 Unique Customers: ${analysisStats.uniqueCustomers}\n`;
      }
      
      if (analysisStats.dateRange) {
        const start = new Date(analysisStats.dateRange.earliest);
        const end = new Date(analysisStats.dateRange.latest);
        if (!isNaN(start.getTime()) && !isNaN(end.getTime())) {
          message += `📅 Period: ${start.toLocaleDateString()} to ${end.toLocaleDateString()}\n`;
        }
      }
    } else {
      message += `⏳ Extracting transactions...\n`;
      message += `📄 PDF text was extracted successfully\n`;
      message += `🔄 Processing ${analysisStats.textItemsFound || 0} text items from ${analysisStats.pagesProcessed || 0} pages\n`;
    }
    
    if (excluded.length > 0) {
      const excludedAmount = excluded.reduce((sum, e) => sum + e.paidIn, 0);
      message += `\n🚫 Excluded: ${excluded.length} (loans/unusual) - KES ${excludedAmount.toLocaleString()}\n`;
      message += `   Click "Show Excluded" to review these transactions\n`;
    }
    
    if (withdrawals.length > 0) {
      const withdrawnAmount = withdrawals.reduce((sum, w) => sum + w.withdrawn, 0);
      message += `💸 Withdrawals: ${withdrawals.length} - KES ${withdrawnAmount.toLocaleString()}\n`;
    }
    
    if (analysisStats.pagesProcessed) {
      message += `\n📄 Processed: ${analysisStats.pagesProcessed} pages, ${analysisStats.textItemsFound} text items`;
    }
    
    setProgress(message);
    
    // Auto-save the PDF to Documents after successful analysis
    autoSaveToDocuments();
  };

  // Auto-save uploaded M-PESA statement to Documents
  const autoSaveToDocuments = async () => {
    if (!fileInputRef.current?.files?.[0]) return;
    
    const file = fileInputRef.current.files[0];
    
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      const response = await fetch('/api/documents/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include'
      });
      
      if (response.ok) {
        console.log('M-PESA statement auto-saved to Documents');
        // Trigger smart organization after upload
        await fetch('/api/documents/organize-all', {
          method: 'POST',
          credentials: 'include'
        });
      }
    } catch (error) {
      console.warn('Could not auto-save M-PESA statement to Documents:', error);
    }
  };

  const displayInflows = (data: InflowData[]) => {
    let str = 'Receipt No,Completion Time,Details,Paid in (KES)\n';
    str += '─'.repeat(70) + '\n';
    
    if (data.length === 0) {
      str += '(Processing - transactions will appear here)\n';
    } else {
      data.forEach(row => {
        const shortDetails = (row.counterparty || row.details || '').substring(0, 40);
        str += `${row.receipt},${row.time},"${shortDetails}",${row.paidIn.toFixed(2)}\n`;
      });
      
      const total = data.reduce((sum, r) => sum + r.paidIn, 0);
      str += '─'.repeat(70) + '\n';
      str += `TOTAL: ${data.length} transactions, KES ${total.toLocaleString('en-US', { minimumFractionDigits: 2 })}\n`;
    }
    
    setOutput(str);
  };

  const calculateByReceipt = () => {
    if (!startReceipt || !endReceipt) {
      setResult('⚠️ Enter both start and end receipt numbers.');
      return;
    }

    const startIndex = inflowData.findIndex(r => r.receipt === startReceipt.toUpperCase());
    const endIndex = inflowData.findIndex(r => r.receipt === endReceipt.toUpperCase());

    if (startIndex === -1 || endIndex === -1) {
      setResult('❌ One or both receipts not found in the extracted data.');
      return;
    }

    const [from, to] = [Math.min(startIndex, endIndex), Math.max(startIndex, endIndex)];
    const rangeData = inflowData.slice(from, to + 1);
    const total = rangeData.reduce((sum, row) => sum + row.paidIn, 0);

    setResult(`
✅ CALCULATION COMPLETE

From: ${inflowData[from].receipt} (${new Date(inflowData[from].time).toLocaleString()})
To: ${inflowData[to].receipt} (${new Date(inflowData[to].time).toLocaleString()})

Transactions: ${rangeData.length}
Total: KES ${total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
Average: KES ${(total / rangeData.length).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
    `);
  };

  const calculateByTime = () => {
    if (!startTime || !endTime) {
      setResult('⚠️ Please select both start and end times.');
      return;
    }

    const start = new Date(startTime);
    const end = new Date(endTime);

    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      setResult('⚠️ Invalid date format.');
      return;
    }

    if (start > end) {
      setResult('⚠️ Start time must be before end time.');
      return;
    }

    const filtered = inflowData.filter(row => {
      const t = new Date(row.time);
      return t >= start && t <= end;
    });

    if (filtered.length === 0) {
      setResult('🔍 No transactions found in this time range.');
      return;
    }

    const total = filtered.reduce((sum, row) => sum + row.paidIn, 0);

    setResult(`
✅ CALCULATION COMPLETE

From: ${start.toLocaleString()}
To: ${end.toLocaleString()}

Transactions: ${filtered.length}
Total: KES ${total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
Average: KES ${(total / filtered.length).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
    `);
  };

  const exportToCSV = () => {
    let rangeData: InflowData[] = [];
    let rangeType = '';

    if (startReceipt && endReceipt) {
      const startIndex = inflowData.findIndex(r => r.receipt === startReceipt.toUpperCase());
      const endIndex = inflowData.findIndex(r => r.receipt === endReceipt.toUpperCase());

      if (startIndex === -1 || endIndex === -1) {
        alert('❌ One or both receipts not found.');
        return;
      }

      const [from, to] = [Math.min(startIndex, endIndex), Math.max(startIndex, endIndex)];
      rangeData = inflowData.slice(from, to + 1);
      rangeType = 'Receipt_Range';
    } else if (startTime && endTime) {
      const start = new Date(startTime);
      const end = new Date(endTime);
      
      if (isNaN(start.getTime()) || isNaN(end.getTime())) {
        alert('⚠️ Invalid date format.');
        return;
      }

      rangeData = inflowData.filter(row => {
        const t = new Date(row.time);
        return t >= start && t <= end;
      });
      rangeType = 'Time_Range';
    } else {
      rangeData = inflowData;
      rangeType = 'All';
    }

    if (rangeData.length === 0) {
      alert('No inflows in the selected range.');
      return;
    }

    const total = rangeData.reduce((sum, r) => sum + r.paidIn, 0);

    let csv = 'M-PESA INFLOW ANALYSIS\n';
    csv += `Export Date,${new Date().toLocaleString()}\n`;
    if (merchantInfo?.name) csv += `Merchant,${merchantInfo.name}\n`;
    csv += `Total Transactions,${rangeData.length}\n`;
    csv += `Total Amount,KES ${total.toFixed(2)}\n`;
    csv += '\n';
    csv += 'Receipt No,Completion Time,Transaction Type,Counterparty,Details,Paid in (KES),Fee (KES)\n';
    
    rangeData.forEach(r => {
      const details = (r.details || '').replace(/"/g, '""');
      const counterparty = (r.counterparty || '').replace(/"/g, '""');
      csv += `${r.receipt},${r.time},"${r.transactionType || ''}","${counterparty}","${details}",${r.paidIn.toFixed(2)},${(r.fee || 0).toFixed(2)}\n`;
    });

    csv += '\n';
    csv += `SUMMARY,,,,,\n`;
    csv += `Total Transactions,${rangeData.length},,,,\n`;
    csv += `Total Amount,,,,,${total.toFixed(2)}\n`;
    csv += `Average Transaction,,,,,${(total / rangeData.length).toFixed(2)}\n`;

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `M-PESA_Inflows_${rangeType}_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-4 md:p-6 space-y-4 md:space-y-6">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-4 md:p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-6 pb-4 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl md:text-2xl font-bold text-blue-900 dark:text-blue-200">📊 M-PESA Inflow Analyzer</h2>
          <div className="text-xs text-gray-500 dark:text-gray-400">
            {pdfLoaded ? '✅ PDF Reader Ready' : '⏳ Loading PDF Reader...'}
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg p-4 mb-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" size={20} />
            <div className="text-sm text-blue-900 dark:text-blue-100">
              <p className="font-semibold mb-2">How it works:</p>
              <ul className="list-disc list-inside space-y-1 text-blue-800 dark:text-blue-200">
                <li>Upload your M-PESA PDF statement (any merchant or personal)</li>
                <li><strong className="text-purple-600 dark:text-purple-400">🤖 AI Mode:</strong> Google Gemini extracts all transactions intelligently</li>
                <li><strong className="text-green-600 dark:text-green-400">✓ Includes:</strong> Customer payments, transfers received, refunds</li>
                <li><strong className="text-red-600 dark:text-red-400">✗ Excludes:</strong> Loans (Fuliza, M-Shwari) flagged for review</li>
                <li>4 extraction methods ensure maximum coverage</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Drag & Drop Zone */}
        <div
          ref={dropZoneRef}
          className="border-3 border-dashed border-blue-400 dark:border-blue-600 p-6 md:p-8 text-center mb-6 bg-blue-50 dark:bg-blue-900/20 rounded-xl cursor-pointer transition-all hover:border-blue-600 hover:bg-blue-100 dark:hover:bg-blue-900/30"
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload size={32} className="mx-auto mb-3 text-blue-600 dark:text-blue-400" />
          <p className="text-base md:text-lg font-semibold text-gray-800 dark:text-gray-200 mb-1">
            Drag & Drop M-PESA PDF Here
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">or click to browse</p>
          <div className="text-sm text-blue-600 dark:text-blue-400 font-medium break-all">
            {fileName}
          </div>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf"
          onChange={handleFileSelect}
          className="hidden"
        />

        {/* AI Toggle */}
        <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 border border-purple-200 dark:border-purple-700 rounded-lg mb-4">
          <div className="flex items-center gap-3">
            <Sparkles className="text-purple-600 dark:text-purple-400" size={20} />
            <div>
              <p className="font-semibold text-gray-800 dark:text-gray-200">AI-Powered Analysis</p>
              <p className="text-xs text-gray-600 dark:text-gray-400">Google Gemini for comprehensive extraction</p>
            </div>
          </div>
          <button
            onClick={() => setUseAI(!useAI)}
            className={`relative w-14 h-7 rounded-full transition-colors ${
              useAI ? 'bg-purple-600' : 'bg-gray-300 dark:bg-gray-600'
            }`}
          >
            <span
              className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-transform ${
                useAI ? 'translate-x-8' : 'translate-x-1'
              }`}
            />
          </button>
        </div>

        {/* Process Button */}
        <button 
          onClick={processPDF}
          disabled={isProcessing || !pdfLoaded}
          className={`w-full font-semibold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2 mb-6 ${
            isProcessing || !pdfLoaded
              ? 'bg-gray-400 cursor-not-allowed text-white'
              : useAI 
                ? 'bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white'
                : 'bg-blue-600 hover:bg-blue-700 text-white'
          }`}
        >
          {isProcessing ? (
            <>
              <RefreshCw size={20} className="animate-spin" />
              Processing...
            </>
          ) : useAI ? (
            <>
              <Sparkles size={20} />
              Process with AI (Gemini)
            </>
          ) : (
            <>
              <Zap size={20} />
              Process PDF (Pattern-based)
            </>
          )}
        </button>

        {/* Progress/Status */}
        <div className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg p-4 mb-6">
          <div className="flex items-start gap-2">
            <CheckCircle2 className="text-green-600 flex-shrink-0 mt-0.5" size={18} />
            <pre className="text-sm font-mono text-gray-700 dark:text-gray-300 whitespace-pre-wrap flex-1 overflow-x-auto">
              {progress}
            </pre>
          </div>
        </div>

        {/* Statistics Cards */}
        {stats && stats.totalInflows > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 mb-6">
            <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700 rounded-lg p-3 md:p-4 text-center">
              <div className="text-xl md:text-2xl font-bold text-green-600 dark:text-green-400">
                {stats.totalInflows}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">Valid Inflows</div>
            </div>
            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg p-3 md:p-4 text-center">
              <div className="text-sm md:text-lg font-bold text-blue-600 dark:text-blue-400">
                KES {stats.totalAmount.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">Total Received</div>
            </div>
            <div className="bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-700 rounded-lg p-3 md:p-4 text-center">
              <div className="text-sm md:text-lg font-bold text-purple-600 dark:text-purple-400">
                KES {stats.averageTransaction.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">Average</div>
            </div>
            <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-700 rounded-lg p-3 md:p-4 text-center">
              <div className="text-xl md:text-2xl font-bold text-orange-600 dark:text-orange-400">
                {stats.totalExcluded}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">Excluded</div>
            </div>
          </div>
        )}

        {/* Extracted Data Display */}
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200">
            ✅ Extracted Inflow Data
          </h3>
          {excludedData.length > 0 && (
            <button
              onClick={() => setShowExcluded(!showExcluded)}
              className="text-sm text-orange-600 dark:text-orange-400 hover:underline"
            >
              {showExcluded ? 'Hide' : 'Show'} Excluded ({excludedData.length})
            </button>
          )}
        </div>
        
        <div className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg p-4 mb-6 overflow-auto" style={{ maxHeight: '300px' }}>
          <pre className="text-xs font-mono text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
            {output}
          </pre>
        </div>

        {/* Excluded Transactions (collapsible) */}
        {showExcluded && excludedData.length > 0 && (
          <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-700 rounded-lg p-4 mb-6">
            <h4 className="font-semibold text-orange-800 dark:text-orange-200 mb-3">
              🚫 Excluded Transactions (Manual Review Required)
            </h4>
            <div className="overflow-auto" style={{ maxHeight: '200px' }}>
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-left border-b border-orange-300 dark:border-orange-700">
                    <th className="pb-2 pr-2">Receipt</th>
                    <th className="pb-2 pr-2">Time</th>
                    <th className="pb-2 pr-2">Amount</th>
                    <th className="pb-2">Reason</th>
                  </tr>
                </thead>
                <tbody>
                  {excludedData.map((item, i) => (
                    <tr key={i} className="border-b border-orange-200 dark:border-orange-800">
                      <td className="py-2 pr-2 font-mono">{item.receipt}</td>
                      <td className="py-2 pr-2">{item.time}</td>
                      <td className="py-2 pr-2">KES {item.paidIn.toLocaleString()}</td>
                      <td className="py-2 text-orange-700 dark:text-orange-300">{item.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Calculation Tabs */}
        <div className="flex border-b border-gray-200 dark:border-gray-700 mb-6">
          <button
            className={`px-4 md:px-6 py-3 font-semibold transition-colors text-sm md:text-base ${
              activeTab === 'receipt'
                ? 'border-b-2 border-blue-600 text-blue-600 dark:text-blue-400'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'
            }`}
            onClick={() => setActiveTab('receipt')}
          >
            By Receipt Range
          </button>
          <button
            className={`px-4 md:px-6 py-3 font-semibold transition-colors text-sm md:text-base ${
              activeTab === 'time'
                ? 'border-b-2 border-blue-600 text-blue-600 dark:text-blue-400'
                : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'
            }`}
            onClick={() => setActiveTab('time')}
          >
            By Time Range
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === 'receipt' && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                Start Receipt Number
              </label>
              <input
                type="text"
                value={startReceipt}
                onChange={(e) => setStartReceipt(e.target.value.toUpperCase())}
                placeholder="e.g. THE4DRLUXK"
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                End Receipt Number
              </label>
              <input
                type="text"
                value={endReceipt}
                onChange={(e) => setEndReceipt(e.target.value.toUpperCase())}
                placeholder="e.g. THF0HJ8LDW"
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
              />
            </div>
            <button 
              onClick={calculateByReceipt} 
              className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <Calculator size={18} />
              Calculate Total for Receipt Range
            </button>
          </div>
        )}

        {activeTab === 'time' && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                Start Date & Time
              </label>
              <input
                type="datetime-local"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                End Date & Time
              </label>
              <input
                type="datetime-local"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
              />
            </div>
            <button 
              onClick={calculateByTime} 
              className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <Clock size={18} />
              Calculate Total for Time Range
            </button>
          </div>
        )}

        {/* Export Button */}
        <button 
          onClick={exportToCSV} 
          disabled={inflowData.length === 0}
          className={`w-full mt-4 font-semibold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2 ${
            inflowData.length === 0 
              ? 'bg-gray-400 cursor-not-allowed text-white'
              : 'bg-gray-600 hover:bg-gray-700 text-white'
          }`}
        >
          <Download size={18} />
          Export to CSV
        </button>

        {/* Calculation Result */}
        {result && (
          <div className="mt-6 bg-green-50 dark:bg-green-900/20 border-2 border-green-300 dark:border-green-700 rounded-lg p-6">
            <pre className="text-sm font-mono text-green-900 dark:text-green-100 whitespace-pre-wrap font-semibold">
              {result}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}
