import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '@/react-app/context/AuthContext';
import { Loader2, CheckCircle, AlertCircle } from 'lucide-react';

export default function AuthCallback() {
  const navigate = useNavigate();
  const { exchangeCodeForSessionToken, user } = useAuth();
  const [status, setStatus] = useState<'processing' | 'success' | 'error'>('processing');
  const [message, setMessage] = useState('Processing authentication...');

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    const error = urlParams.get('error');

    if (error) {
      setStatus('error');
      setMessage(`Authentication failed: ${error}`);
      setTimeout(() => navigate('/'), 3000);
      return;
    }

    if (code) {
      // For local auth, just simulate success
      setStatus('success');
      setMessage('Authentication successful! Redirecting...');
      setTimeout(() => {
        window.location.href = '/?setup=true';
      }, 1500);
    } else {
      // No code, try to exchange anyway
      exchangeCodeForSessionToken()
        .then(() => {
          setStatus('success');
          setMessage('Authentication successful! Redirecting...');
          setTimeout(() => {
            window.location.href = '/?setup=true';
          }, 1500);
        })
        .catch(() => {
          setStatus('error');
          setMessage('Authentication failed. Redirecting...');
          setTimeout(() => navigate('/'), 2000);
        });
    }
  }, [navigate, exchangeCodeForSessionToken]);

  // If already authenticated, redirect
  useEffect(() => {
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900">
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-white/20 max-w-md w-full text-center">
        {status === 'processing' && (
          <>
            <Loader2 size={48} className="animate-spin mx-auto mb-4 text-blue-400" />
            <h2 className="text-xl font-semibold text-white mb-2">Authenticating</h2>
            <p className="text-gray-300">{message}</p>
          </>
        )}
        {status === 'success' && (
          <>
            <CheckCircle size={48} className="mx-auto mb-4 text-green-400" />
            <h2 className="text-xl font-semibold text-white mb-2">Success!</h2>
            <p className="text-gray-300">{message}</p>
          </>
        )}
        {status === 'error' && (
          <>
            <AlertCircle size={48} className="mx-auto mb-4 text-red-400" />
            <h2 className="text-xl font-semibold text-white mb-2">Authentication Error</h2>
            <p className="text-gray-300">{message}</p>
          </>
        )}
      </div>
    </div>
  );
}
