import React, { useRef } from 'react';
import { Moon, Sun, Settings, Image, LogOut, Cloud, CloudOff, User, QrCode } from 'lucide-react';
import { useFuel } from '@/react-app/context/FuelContext';
import { useAuth } from '@/react-app/context/AuthContext';
import StationSelector from './StationSelector';

export default function Header() {
  const { state, dispatch, isCloudSaving, lastCloudSave } = useFuel();
  const { user, logout } = useAuth();
  const logoInputRef = useRef<HTMLInputElement>(null);

  const handleQRCodeDownload = async () => {
    const qrCodeDownloadUrl = 'https://mocha-cdn.com/0199d39d-8fc8-7b37-bf10-097a162ee9f3/IMG-20251205-WA0001.jpg';
    
    try {
      // Fetch the image as a blob
      const response = await fetch(qrCodeDownloadUrl, {
        mode: 'cors',
        cache: 'no-cache'
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch image');
      }
      
      const blob = await response.blob();
      
      // Create a temporary URL for the blob
      const blobUrl = URL.createObjectURL(blob);
      
      // Create and trigger download
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = 'FuelPro-QR-Code.jpg';
      link.style.display = 'none';
      
      document.body.appendChild(link);
      link.click();
      
      // Clean up
      setTimeout(() => {
        document.body.removeChild(link);
        URL.revokeObjectURL(blobUrl);
      }, 100);
      
    } catch (error) {
      console.error('Download failed:', error);
      // Fallback: open in new tab so user can save manually
      window.open(qrCodeDownloadUrl, '_blank');
    }
  };

  const toggleTheme = () => {
    dispatch({ 
      type: 'SET_THEME', 
      payload: state.theme === 'light' ? 'dark' : 'light' 
    });
  };

  const editBusinessInfo = () => {
    const name = prompt('Company Name:', state.companyData.name) || state.companyData.name;
    const poBox = prompt('P.O. Box:', state.companyData.poBox) || state.companyData.poBox;
    const contacts = prompt('CONTACTS (e.g., +254...):', state.companyData.contacts) || state.companyData.contacts;
    const email = prompt('EMAIL Address:', state.companyData.email) || state.companyData.email;
    
    // Bank details for invoice payments
    const bankName = prompt('Bank Name (for invoices):', state.companyData.bankName) || state.companyData.bankName;
    const branchName = prompt('Branch Name:', state.companyData.branchName) || state.companyData.branchName;
    const accountHolder = prompt('Account Holder Name:', state.companyData.accountHolder) || state.companyData.accountHolder;
    const accountNumber = prompt('Account Number:', state.companyData.accountNumber) || state.companyData.accountNumber;
    
    // Currency selection dialog
    let currency = state.companyData.currency;
    
    const currencyChoice = prompt(
      `Select Currency:\n1. Ksh (Kenyan Shilling)\n2. $ (US Dollar)\n3. Custom\n\nEnter 1, 2, or 3:`,
      state.companyData.currency === 'Ksh' ? '1' : state.companyData.currency === '$' ? '2' : '3'
    );
    
    if (currencyChoice === '1') {
      currency = 'Ksh';
    } else if (currencyChoice === '2') {
      currency = '$';
    } else if (currencyChoice === '3') {
      const customCurrency = prompt('Enter custom currency symbol:', state.companyData.currency);
      if (customCurrency) {
        currency = customCurrency;
      }
    }
    
    dispatch({
      type: 'SET_COMPANY_DATA',
      payload: { 
        name, 
        poBox, 
        contacts, 
        email, 
        logo: state.companyData.logo, 
        currency,
        bankName,
        branchName,
        accountHolder,
        accountNumber,
        kraPin: state.companyData.kraPin || '',
        vatRegNo: state.companyData.vatRegNo || '',
        physicalAddress: state.companyData.physicalAddress || '',
        county: state.companyData.county || '',
        town: state.companyData.town || '',
        etrSerialNo: state.companyData.etrSerialNo || '',
        cuSerialNo: state.companyData.cuSerialNo || '',
        etrInvoicePrefix: state.companyData.etrInvoicePrefix || 'INV'
      }
    });
    
    alert('Business info updated! Bank details will appear on invoices.');
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (ev) => {
      if (ev.target?.result) {
        dispatch({
          type: 'SET_COMPANY_DATA',
          payload: { ...state.companyData, logo: ev.target.result as string }
        });
        alert('Logo uploaded successfully!');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleLogout = async () => {
    if (confirm('Are you sure you want to logout? All unsaved changes will be lost.')) {
      try {
        await logout();
      } catch (error) {
        console.error('Logout error:', error);
        alert('Logout failed. Please try again.');
      }
    }
  };

  const getCloudStatus = () => {
    if (isCloudSaving) {
      return {
        icon: Cloud,
        text: 'Saving...',
        color: 'text-blue-500 animate-pulse'
      };
    }
    
    if (lastCloudSave) {
      const timeDiff = Date.now() - lastCloudSave.getTime();
      const minutes = Math.floor(timeDiff / 60000);
      
      return {
        icon: Cloud,
        text: minutes < 1 ? 'Just saved' : `${minutes}m ago`,
        color: 'text-green-500'
      };
    }
    
    return {
      icon: CloudOff,
      text: 'Not synced',
      color: 'text-gray-400'
    };
  };

  const cloudStatus = getCloudStatus();

  return (
    <header className="sticky top-0 z-50 bg-white/95 dark:bg-gray-900/95 backdrop-blur-lg shadow-lg border-b-2 border-yellow-400 transition-all duration-300">
      {/* Mobile Layout - Ultra Compact Single Row */}
      <div className="md:hidden">
        <div className="flex items-center gap-1 p-1.5 overflow-x-auto scrollbar-hide">
          {/* Logo - Compact */}
          {state.companyData.logo && (
            <img 
              src={state.companyData.logo} 
              alt="Logo" 
              className="h-10 w-10 rounded-lg border border-yellow-400 flex-shrink-0"
            />
          )}
          
          {/* Company Name - Compact */}
          <div className="min-w-0 flex-shrink-0 max-w-[120px]">
            <h1 className="text-xs font-bold text-blue-900 dark:text-blue-200 truncate leading-tight">
              {state.companyData.name || 'Company Name'}
            </h1>
          </div>
          
          {/* Station Selector - Compact Mobile */}
          <div className="flex-shrink-0">
            <StationSelector compact />
          </div>

          {/* User Profile - Compact */}
          {user && (
            <div className="flex-shrink-0 ml-1">
              {user.google_user_data?.picture ? (
                <img 
                  src={user.google_user_data.picture} 
                  alt="Profile" 
                  className="w-8 h-8 rounded-full border border-gray-300"
                />
              ) : (
                <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center border border-gray-300">
                  <User size={14} className="text-gray-600 dark:text-gray-300" />
                </div>
              )}
            </div>
          )}

          {/* Divider */}
          <div className="h-8 w-px bg-gray-300 dark:bg-gray-600 mx-1 flex-shrink-0"></div>

          {/* Action Buttons - Icon Only, Compact */}
          <button
            onClick={toggleTheme}
            className="flex items-center justify-center w-10 h-10 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg flex-shrink-0 transition-colors"
            title="Toggle theme"
          >
            {state.theme === 'light' ? <Moon size={16} /> : <Sun size={16} />}
          </button>
          
          <button
            onClick={editBusinessInfo}
            className="flex items-center justify-center w-10 h-10 bg-blue-100 dark:bg-blue-900/30 hover:bg-blue-200 dark:hover:bg-blue-800/40 text-blue-700 dark:text-blue-300 rounded-lg flex-shrink-0 transition-colors"
            title="Customize"
          >
            <Settings size={16} />
          </button>
          
          <button
            onClick={() => logoInputRef.current?.click()}
            className="flex items-center justify-center w-10 h-10 bg-purple-100 dark:bg-purple-900/30 hover:bg-purple-200 dark:hover:bg-purple-800/40 text-purple-700 dark:text-purple-300 rounded-lg flex-shrink-0 transition-colors"
            title="Upload logo"
          >
            <Image size={16} />
          </button>

          <button
            onClick={handleQRCodeDownload}
            className="flex items-center justify-center w-10 h-10 bg-green-100 dark:bg-green-900/30 hover:bg-green-200 dark:hover:bg-green-800/40 text-green-700 dark:text-green-300 rounded-lg flex-shrink-0 transition-colors"
            title="Download QR Code"
          >
            <QrCode size={16} />
          </button>

          <button
            onClick={handleLogout}
            className="flex items-center justify-center w-10 h-10 bg-red-100 dark:bg-red-900/30 hover:bg-red-200 dark:hover:bg-red-800/40 text-red-700 dark:text-red-300 rounded-lg flex-shrink-0 transition-colors"
            title="Logout"
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>

      {/* Desktop Layout - Original */}
      <div className="hidden md:flex justify-between items-center p-4">
        <div className="flex items-center gap-4">
          {state.companyData.logo && (
            <img 
              src={state.companyData.logo} 
              alt="Logo" 
              className="h-12 w-12 rounded-xl border-2 border-yellow-400"
            />
          )}
          <div>
            <h1 className="text-2xl font-bold text-blue-900 dark:text-blue-200 font-serif">
              {state.companyData.name || 'Company Name'}
            </h1>
            <p className="text-sm text-yellow-600 dark:text-yellow-400 font-semibold">
              Fuel Distribution & Management System
            </p>
          </div>
          
          {/* Station Selector */}
          <StationSelector />
        </div>
        
        <div className="flex items-center gap-3">
          {/* Cloud Sync Status */}
          <div className="flex items-center gap-2 px-3 py-1 bg-white/50 dark:bg-gray-800/50 rounded-lg border border-gray-200 dark:border-gray-600">
            <cloudStatus.icon size={14} className={cloudStatus.color} />
            <span className="text-xs text-gray-600 dark:text-gray-300">{cloudStatus.text}</span>
          </div>

          {/* User Info */}
          {user && (
            <div className="flex items-center gap-2 px-3 py-1 bg-white/50 dark:bg-gray-800/50 rounded-lg border border-gray-200 dark:border-gray-600">
              {user.google_user_data?.picture ? (
                <img 
                  src={user.google_user_data.picture} 
                  alt="Profile" 
                  className="w-6 h-6 rounded-full border border-gray-300"
                />
              ) : (
                <User size={14} className="text-gray-600 dark:text-gray-300" />
              )}
              <span className="text-xs text-gray-700 dark:text-gray-200 max-w-32 truncate">
                {user.google_user_data?.name || user.email}
              </span>
            </div>
          )}

          <div className="flex gap-2">
            <button
              onClick={toggleTheme}
              className="btn btn-outline p-2"
              title="Toggle theme"
            >
              {state.theme === 'light' ? <Moon size={14} /> : <Sun size={14} />}
            </button>
            
            <button
              onClick={editBusinessInfo}
              className="btn btn-secondary p-2"
              title="Edit business info"
            >
              <Settings size={14} />
              <span className="hidden lg:inline ml-1">Edit Info</span>
            </button>
            
            <button
              onClick={() => logoInputRef.current?.click()}
              className="btn btn-primary p-2"
              title="Upload logo"
            >
              <Image size={14} />
              <span className="hidden lg:inline ml-1">Logo</span>
            </button>

            <button
              onClick={handleQRCodeDownload}
              className="btn btn-primary bg-green-600 hover:bg-green-700 border-green-600 p-2"
              title="Download QR Code"
            >
              <QrCode size={14} />
              <span className="hidden lg:inline ml-1">QR Code</span>
            </button>

            <button
              onClick={handleLogout}
              className="btn btn-outline text-red-600 border-red-300 hover:bg-red-50 dark:hover:bg-red-900/20 p-2"
              title="Logout"
            >
              <LogOut size={14} />
              <span className="ml-1">Logout</span>
            </button>
          </div>
        </div>
      </div>

      <input
        ref={logoInputRef}
        type="file"
        accept="image/*"
        onChange={handleLogoUpload}
        className="hidden"
      />
    </header>
  );
}
