import { Truck, FileText, Bell, BarChart3, TrendingUp, Users, Home, Database, Package, ChartPie, MessageCircle, CreditCard, FileBarChart, ChevronLeft, ChevronRight, ShoppingCart, FolderOpen } from 'lucide-react';
import { useFuel } from '@/react-app/context/FuelContext';
import { useRef, useState, useEffect } from 'react';

interface TabNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function TabNavigation({ activeTab, onTabChange }: TabNavigationProps) {
  const { state } = useFuel();
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const scrollbarRef = useRef<HTMLDivElement>(null);
  const [showLeftScroll, setShowLeftScroll] = useState(false);
  const [showRightScroll, setShowRightScroll] = useState(false);
  const [scrollPercentage, setScrollPercentage] = useState(0);
  const [thumbWidth, setThumbWidth] = useState(100);
  const [isDragging, setIsDragging] = useState(false);
  
  // Icon mapping for each tab
  const tabIcons: Record<string, any> = {
    dashboard: Home,
    delivery: Truck,
    offloading: Package,
    invoice: FileText,
    debt: Bell,
    sales: BarChart3,
    reports: ChartPie,
    fuelsalesreport: FileBarChart,
    mpesa: TrendingUp,
    livetransaction: CreditCard,
    payroll: Users,
    communication: MessageCircle,
    documents: FolderOpen,
    data: Database,
    pos: ShoppingCart,
  };

  // Get tabs from configurations, sorted by order and filtered by visibility
  const tabs = state.tabConfigurations
    .filter(tab => tab.visible)
    .sort((a, b) => a.order - b.order)
    .map(tabConfig => ({
      id: tabConfig.id,
      label: tabConfig.label, // Use custom label if set
      icon: tabIcons[tabConfig.id] || Home
    }));

  const updateScrollInfo = () => {
    if (scrollContainerRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
      setShowLeftScroll(scrollLeft > 10);
      setShowRightScroll(scrollLeft < scrollWidth - clientWidth - 10);
      
      // Calculate scroll percentage and thumb width
      if (scrollWidth > clientWidth) {
        const percentage = (scrollLeft / (scrollWidth - clientWidth)) * 100;
        setScrollPercentage(percentage);
        
        // Thumb width represents the visible portion
        const thumbWidthPercent = (clientWidth / scrollWidth) * 100;
        setThumbWidth(Math.max(thumbWidthPercent, 15)); // Minimum 15% width
      } else {
        setScrollPercentage(0);
        setThumbWidth(100);
      }
    }
  };

  useEffect(() => {
    updateScrollInfo();
    window.addEventListener('resize', updateScrollInfo);
    return () => window.removeEventListener('resize', updateScrollInfo);
  }, [tabs]);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = 300;
      const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
      const maxScroll = scrollWidth - clientWidth;
      
      let newScrollLeft = direction === 'left' 
        ? scrollLeft - scrollAmount
        : scrollLeft + scrollAmount;
      
      // Clamp scroll position to prevent overshooting
      newScrollLeft = Math.max(0, Math.min(newScrollLeft, maxScroll));
      
      scrollContainerRef.current.scrollTo({
        left: newScrollLeft,
        behavior: 'smooth'
      });
    }
  };

  const handleScrollbarClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!scrollContainerRef.current || !scrollbarRef.current) return;
    
    const scrollbarRect = scrollbarRef.current.getBoundingClientRect();
    const clickX = e.clientX - scrollbarRect.left;
    const clickPercentage = (clickX / scrollbarRect.width) * 100;
    
    const { scrollWidth, clientWidth } = scrollContainerRef.current;
    const maxScroll = scrollWidth - clientWidth;
    let newScrollLeft = (clickPercentage / 100) * maxScroll;
    
    // Clamp scroll position to prevent overshooting
    newScrollLeft = Math.max(0, Math.min(newScrollLeft, maxScroll));
    
    scrollContainerRef.current.scrollTo({
      left: newScrollLeft,
      behavior: 'smooth'
    });
  };

  const handleThumbDrag = (e: React.MouseEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
    
    const startX = e.clientX;
    const scrollbarRect = scrollbarRef.current?.getBoundingClientRect();
    if (!scrollbarRect || !scrollContainerRef.current) return;
    
    const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
    const maxScroll = scrollWidth - clientWidth;
    
    const handleMouseMove = (moveEvent: MouseEvent) => {
      if (!scrollbarRef.current || !scrollContainerRef.current) return;
      
      const deltaX = moveEvent.clientX - startX;
      const scrollbarWidth = scrollbarRef.current.getBoundingClientRect().width;
      const deltaPercentage = (deltaX / scrollbarWidth) * 100;
      const deltaScroll = (deltaPercentage / 100) * maxScroll;
      
      // Clamp scroll position to prevent overshooting
      const newScrollLeft = Math.max(0, Math.min(scrollLeft + deltaScroll, maxScroll));
      scrollContainerRef.current.scrollLeft = newScrollLeft;
    };
    
    const handleMouseUp = () => {
      setIsDragging(false);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  return (
    <div className="relative bg-white dark:bg-gray-800 rounded-t-2xl shadow-lg">
      {/* Left Scroll Button - Only visible on landscape/desktop */}
      {showLeftScroll && (
        <button
          onClick={() => scroll('left')}
          className="hidden md:flex absolute left-0 top-0 bottom-0 z-10 items-center justify-center w-12 bg-gradient-to-r from-white dark:from-gray-800 to-transparent hover:from-gray-50 dark:hover:from-gray-700 transition-all"
          aria-label="Scroll left"
        >
          <ChevronLeft size={24} className="text-gray-600 dark:text-gray-300" />
        </button>
      )}

      {/* Tabs Container */}
      <div 
        ref={scrollContainerRef}
        onScroll={updateScrollInfo}
        className="flex overflow-x-auto scrollbar-hide p-2 scroll-smooth snap-x snap-mandatory overscroll-x-none"
        style={{ WebkitOverflowScrolling: 'touch' }}
      >
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex items-center gap-2 px-3 md:px-6 py-2 md:py-3 text-sm md:text-lg font-semibold transition-all duration-300 border-b-4 flex-shrink-0 rounded-t-xl snap-start ${
                activeTab === tab.id
                  ? 'text-blue-900 dark:text-yellow-400 border-yellow-500 bg-gradient-to-b from-yellow-100 to-yellow-50 dark:from-yellow-900/40 dark:to-yellow-900/20 shadow-lg shadow-yellow-500/30 dark:shadow-yellow-500/20 scale-105 relative z-10'
                  : 'text-gray-600 dark:text-gray-400 border-transparent hover:text-blue-700 dark:hover:text-yellow-300 hover:bg-gray-50 dark:hover:bg-gray-700/50'
              }`}
            >
              <Icon size={18} className="md:w-5 md:h-5" />
              <span className="whitespace-nowrap">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Right Scroll Button - Only visible on landscape/desktop */}
      {showRightScroll && (
        <button
          onClick={() => scroll('right')}
          className="hidden md:flex absolute right-0 top-0 bottom-0 z-10 items-center justify-center w-12 bg-gradient-to-l from-white dark:from-gray-800 to-transparent hover:from-gray-50 dark:hover:from-gray-700 transition-all"
          aria-label="Scroll right"
        >
          <ChevronRight size={24} className="text-gray-600 dark:text-gray-300" />
        </button>
      )}

      {/* Custom Scrollbar Indicator */}
      {thumbWidth < 100 && (
        <div className="relative h-6 bg-gray-100 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 rounded-b-2xl flex items-center px-2">
          {/* Left Arrow Button */}
          <button
            onClick={() => scroll('left')}
            disabled={!showLeftScroll}
            className={`flex-shrink-0 w-6 h-6 flex items-center justify-center rounded transition-colors ${
              showLeftScroll 
                ? 'text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700' 
                : 'text-gray-300 dark:text-gray-600 cursor-not-allowed'
            }`}
            aria-label="Scroll left"
          >
            <ChevronLeft size={16} />
          </button>

          {/* Scrollbar Track */}
          <div 
            ref={scrollbarRef}
            className="flex-1 h-2 bg-gray-200 dark:bg-gray-700 rounded-full mx-2 relative cursor-pointer"
            onClick={handleScrollbarClick}
          >
            {/* Scrollbar Thumb */}
            <div 
              className={`absolute top-0 h-full bg-gradient-to-r from-blue-500 to-blue-600 dark:from-yellow-500 dark:to-yellow-600 rounded-full shadow-lg transition-all ${
                isDragging ? 'cursor-grabbing' : 'cursor-grab'
              }`}
              style={{
                left: `${scrollPercentage}%`,
                width: `${thumbWidth}%`,
                transform: 'translateX(0)',
              }}
              onMouseDown={handleThumbDrag}
            />
          </div>

          {/* Right Arrow Button */}
          <button
            onClick={() => scroll('right')}
            disabled={!showRightScroll}
            className={`flex-shrink-0 w-6 h-6 flex items-center justify-center rounded transition-colors ${
              showRightScroll 
                ? 'text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700' 
                : 'text-gray-300 dark:text-gray-600 cursor-not-allowed'
            }`}
            aria-label="Scroll right"
          >
            <ChevronRight size={16} />
          </button>
        </div>
      )}
    </div>
  );
}
