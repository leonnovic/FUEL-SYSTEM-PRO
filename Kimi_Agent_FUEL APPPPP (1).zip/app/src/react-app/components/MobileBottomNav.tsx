import { Home, ShoppingCart, BarChart3, FileText, MoreHorizontal, Fuel, Truck, CreditCard, Users, FolderOpen } from 'lucide-react';
import { useState } from 'react';

interface MobileBottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

interface NavItem {
  id: string;
  label: string;
  icon: any;
  color: string;
}

export default function MobileBottomNav({ activeTab, onTabChange }: MobileBottomNavProps) {
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  // Primary nav items (always visible)
  const primaryNav: NavItem[] = [
    { id: 'dashboard', label: 'Home', icon: Home, color: 'text-blue-500' },
    { id: 'pos', label: 'POS', icon: ShoppingCart, color: 'text-green-500' },
    { id: 'sales', label: 'Sales', icon: BarChart3, color: 'text-purple-500' },
    { id: 'reports', label: 'Reports', icon: FileText, color: 'text-orange-500' },
  ];

  // Secondary nav items (in "More" menu)
  const secondaryNav: NavItem[] = [
    { id: 'offloading', label: 'Offloading', icon: Fuel, color: 'text-amber-500' },
    { id: 'delivery', label: 'Deliveries', icon: Truck, color: 'text-teal-500' },
    { id: 'invoice', label: 'Invoices', icon: FileText, color: 'text-indigo-500' },
    { id: 'mpesa', label: 'M-PESA', icon: CreditCard, color: 'text-green-600' },
    { id: 'payroll', label: 'Payroll', icon: Users, color: 'text-pink-500' },
    { id: 'documents', label: 'Documents', icon: FolderOpen, color: 'text-cyan-500' },
  ];

  const handleNavClick = (tabId: string) => {
    onTabChange(tabId);
    setShowMoreMenu(false);
  };

  const isMoreActive = secondaryNav.some(item => item.id === activeTab);

  return (
    <>
      {/* More Menu Overlay */}
      {showMoreMenu && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setShowMoreMenu(false)}
        />
      )}

      {/* More Menu Popup */}
      {showMoreMenu && (
        <div className="fixed bottom-20 left-2 right-2 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl z-50 md:hidden border border-gray-200 dark:border-gray-700 overflow-hidden">
          <div className="p-3 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-sm font-semibold text-gray-600 dark:text-gray-300">More Options</h3>
          </div>
          <div className="grid grid-cols-3 gap-1 p-2">
            {secondaryNav.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex flex-col items-center justify-center p-4 rounded-xl transition-all active:scale-95 ${
                    isActive 
                      ? 'bg-blue-100 dark:bg-blue-900/40' 
                      : 'hover:bg-gray-100 dark:hover:bg-gray-700/50'
                  }`}
                >
                  <Icon 
                    size={24} 
                    className={isActive ? item.color : 'text-gray-500 dark:text-gray-400'} 
                  />
                  <span className={`text-xs mt-1.5 font-medium ${
                    isActive ? 'text-blue-700 dark:text-blue-300' : 'text-gray-600 dark:text-gray-400'
                  }`}>
                    {item.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 z-40 md:hidden safe-area-pb">
        <div className="flex items-center justify-around h-16 px-1">
          {primaryNav.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`flex flex-col items-center justify-center flex-1 h-full py-1 transition-all active:scale-95 relative ${
                  isActive ? '' : ''
                }`}
              >
                {/* Active indicator */}
                {isActive && (
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-b-full" />
                )}
                <div className={`p-1.5 rounded-xl transition-all ${
                  isActive ? 'bg-blue-100 dark:bg-blue-900/40' : ''
                }`}>
                  <Icon 
                    size={22} 
                    className={isActive ? item.color : 'text-gray-400 dark:text-gray-500'} 
                  />
                </div>
                <span className={`text-[10px] mt-0.5 font-medium ${
                  isActive ? 'text-blue-700 dark:text-blue-300' : 'text-gray-500 dark:text-gray-400'
                }`}>
                  {item.label}
                </span>
              </button>
            );
          })}

          {/* More Button */}
          <button
            onClick={() => setShowMoreMenu(!showMoreMenu)}
            className={`flex flex-col items-center justify-center flex-1 h-full py-1 transition-all active:scale-95 relative ${
              isMoreActive ? '' : ''
            }`}
          >
            {isMoreActive && (
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-b-full" />
            )}
            <div className={`p-1.5 rounded-xl transition-all ${
              showMoreMenu || isMoreActive ? 'bg-blue-100 dark:bg-blue-900/40' : ''
            }`}>
              <MoreHorizontal 
                size={22} 
                className={showMoreMenu || isMoreActive ? 'text-blue-500' : 'text-gray-400 dark:text-gray-500'} 
              />
            </div>
            <span className={`text-[10px] mt-0.5 font-medium ${
              showMoreMenu || isMoreActive ? 'text-blue-700 dark:text-blue-300' : 'text-gray-500 dark:text-gray-400'
            }`}>
              More
            </span>
          </button>
        </div>
      </nav>
    </>
  );
}
