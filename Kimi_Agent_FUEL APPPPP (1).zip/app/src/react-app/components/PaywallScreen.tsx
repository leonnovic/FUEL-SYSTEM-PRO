import { useState } from 'react';
import { useAuth } from '@/react-app/context/AuthContext';
import { CreditCard, Clock, Check, Shield, Star, Key, Smartphone, ArrowLeft } from 'lucide-react';

interface PaywallScreenProps {
  onSubscriptionActive: () => void;
}

export default function PaywallScreen({ onSubscriptionActive }: PaywallScreenProps) {
  const { logout } = useAuth();
  const [selectedPlan] = useState<'monthly' | 'yearly'>('monthly');
  const [isProcessing, setIsProcessing] = useState(false);
  const [secretCode, setSecretCode] = useState('');

  const plans = {
    monthly: {
      name: 'Monthly Access',
      price: 2000,
      priceUSD: 15,
      period: 'month',
      description: 'Full access for 30 days',
      features: [
        'Complete Fuel Management System',
        'Real-time Sales Tracking',
        'Invoice Generation',
        'Delivery Management',
        'M-PESA Integration',
        'Data Export & Backup',
        'Technical Support'
      ]
    },
    yearly: {
      name: 'Yearly Access',
      price: 20000,
      priceUSD: 150,
      period: 'year',
      description: 'Full access for 365 days',
      savings: 'Save KSH 4,000',
      features: [
        'Everything in Monthly Plan',
        'Priority Support',
        'Advanced Analytics',
        'Custom Reports',
        'Data History (Unlimited)',
        'Multi-device Sync',
        'Free Updates'
      ]
    }
  };

  const handleUnlock = () => {
    if (secretCode.trim()) {
      setIsProcessing(true);
      setTimeout(() => {
        onSubscriptionActive();
      }, 500);
    }
  };

  const plan = plans[selectedPlan];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Back to Login Button */}
        <div className="pt-8 mb-4">
          <button
            onClick={() => logout()}
            className="flex items-center gap-2 text-white/70 hover:text-white transition-colors duration-300 px-4 py-2 rounded-lg hover:bg-white/10"
          >
            <ArrowLeft size={16} />
            Back to Login
          </button>
        </div>

        {/* Header */}
        <div className="text-center mb-12">
          <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/20 mb-8">
            <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-2xl flex items-center justify-center shadow-lg">
              <span className="text-3xl">⛽</span>
            </div>
            <h1 className="text-4xl font-bold text-white mb-4 font-serif">
              FuelPro Professional
            </h1>
            <p className="text-yellow-200 text-xl font-semibold mb-6">
              Professional Fuel Management System
            </p>
            
            <div className="flex items-center justify-center gap-6 text-white/90 flex-wrap">
              <div className="flex items-center gap-2">
                <Shield className="text-green-400" size={20} />
                <span>Secure & Reliable</span>
              </div>
              <div className="flex items-center gap-2">
                <Star className="text-yellow-400" size={20} />
                <span>Enterprise Grade</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="text-blue-400" size={20} />
                <span>24/7 Access</span>
              </div>
            </div>
          </div>
        </div>

        {/* Plan Card */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-white/20 mb-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
            <div className="text-4xl font-bold text-yellow-400 mb-2">
              KSH {plan.price.toLocaleString()}
            </div>
            <p className="text-gray-300 mb-6">{plan.description}</p>
            
            <div className="space-y-3 text-left max-w-md mx-auto">
              {plan.features.map((feature, index) => (
                <div key={index} className="flex items-center gap-3">
                  <Check size={16} className="text-green-400 flex-shrink-0" />
                  <span className="text-gray-200">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Unlock with Code */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-white/20 mb-8">
          <div className="text-center mb-6">
            <Key size={48} className="mx-auto text-yellow-400 mb-4" />
            <h3 className="text-2xl font-bold text-white mb-2">Enter Access Code</h3>
            <p className="text-gray-300">Enter your access code to unlock full access</p>
          </div>

          <div className="max-w-md mx-auto space-y-4">
            <input
              type="password"
              value={secretCode}
              onChange={(e) => setSecretCode(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleUnlock()}
              placeholder="Enter access code"
              className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            />
            <button
              onClick={handleUnlock}
              disabled={isProcessing || !secretCode.trim()}
              className="w-full flex items-center justify-center gap-2 bg-yellow-500 hover:bg-yellow-600 disabled:bg-gray-600 disabled:cursor-not-allowed text-gray-900 font-semibold py-3 px-6 rounded-lg transition-all duration-300"
            >
              <Smartphone size={20} />
              {isProcessing ? 'Unlocking...' : 'Unlock Access'}
            </button>
          </div>

          <div className="bg-yellow-500/20 border border-yellow-500 rounded-lg p-3 text-center mt-6">
            <p className="text-yellow-200 text-sm">
              Demo Mode: Enter any code to access the system
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-12 pb-8">
          <p className="text-white/70 text-sm mb-4">
            FuelPro Professional • Professional Fuel Management
          </p>
          <div className="flex justify-center items-center gap-6 text-white/50 text-xs">
            <span>Secure</span>
            <span>•</span>
            <span>Reliable</span>
            <span>•</span>
            <span>Professional</span>
          </div>
        </div>
      </div>
    </div>
  );
}
